<div class="menu">
    <span class="pure-menu-heading">switch conf</span>
    <a href="login.php" class="pure-menu-link">Se connecter</a>
</div>