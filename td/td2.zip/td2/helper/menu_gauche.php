<div class="pure-menu">
    <ul class="pure-menu-list">
        <li class="pure-menu-item">
            <a href="index.php" class="pure-menu-link">Utilisateurs</a>
        </li>
        <li class="pure-menu-item">
            <a href="equipments_list.php" class="pure-menu-link">Équipements</a>
        </li>
    </ul>
</div>